# NEXUS 2.0 — Cloud-Native AI Log Intelligence

A full-stack academic AIOps / Cloud + DevOps project. Visual direction follows the user's ScrapeFlow starter: midnight background, violet/cyan accents, glass surfaces, grid texture, clean typography and motion.

## Stack
- Next.js 15 + React + Tailwind + Framer Motion + Recharts
- FastAPI + SQLAlchemy + PostgreSQL
- Redis + Celery worker for background analysis
- Drain3 (streaming log-template parsing; regex fallback)
- TF-IDF + Isolation Forest (unsupervised anomaly scoring baseline)
- Evidence-based RCA ranking (time order + service/error signatures)
- Optional Gemini explanation (server-side API key)
- Docker Compose, Kubernetes manifests, Terraform starter, GitHub Actions
- Prometheus metrics + Grafana + Loki configuration

## Dataset
- Built-in deterministic microservice fault-injection dataset for repeatable demos.
- Public benchmark target: LogHub HDFS_v1 (labelled HDFS block traces) and BGL (alert-tagged logs). Use `python scripts/download_loghub.py --dataset HDFS` to download the HDFS_v1 archive into `data/raw/`; the archive is ~1.47 GiB. `--dataset BGL` downloads the larger BGL archive.
- Dataset provenance and citations are in `docs/RESEARCH.md`. Respect LogHub's research-use terms and cite the dataset paper.
- This package does not silently claim benchmark results: run `scripts/evaluate.py` after preparing labelled data to calculate precision, recall, F1 and confusion matrix.

## Run locally (Docker recommended)
1. Install Docker Desktop and start its Linux engine.
2. Copy `.env.example` to `.env`; Gemini is optional.
3. Run `docker compose up --build`.
4. Open frontend `http://localhost:3000`; API docs `http://localhost:8000/docs`; Grafana `http://localhost:3001`; Prometheus `http://localhost:9090`; Loki `http://localhost:3100`.
5. Select **Load demo scenario** to populate data, or upload `.log` / `.txt` / `.csv`.

## Run without Docker (development)
Backend:
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
Frontend in a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Set `NEXT_PUBLIC_API_URL=http://localhost:8000` in `frontend/.env.local`.

## ML method (honest description)
1. Drain3 mines recurring log templates when installed; regex normalisation is fallback.
2. TF-IDF converts normalized messages to sparse text features.
3. Isolation Forest scores unusual messages without requiring anomaly labels.
4. Rule/context signals (severity, time ordering, service names, dependency relationships) rank candidate causes.
5. Optional Gemini only explains the selected evidence. It is not the detector.
The prototype is an academic baseline, not a production-grade or calibrated incident probability model.

## DevOps demo
- `docker compose up --build`: multi-container deployment.
- `docker compose ps`: service status.
- `docker compose logs -f worker`: background analysis worker.
- Kubernetes demo (build images locally first):
```bash
docker build -t nexus-api:2.0.0 -f backend/Dockerfile .
docker build -t nexus-web:2.0.0 ./frontend
# For Minikube, load both images: minikube image load nexus-api:2.0.0 && minikube image load nexus-web:2.0.0
kubectl apply -f deploy/kubernetes/namespace.yaml
kubectl apply -f deploy/kubernetes/postgres.yaml
kubectl apply -f deploy/kubernetes/redis.yaml
kubectl apply -f deploy/kubernetes/api.yaml
kubectl apply -f deploy/kubernetes/worker.yaml
kubectl apply -f deploy/kubernetes/web.yaml
kubectl get pods -n nexus
```
The Kubernetes YAML is a learning/demo deployment; adjust secrets, ingress, storage class, resource limits and image registry for production.
- GitHub Actions runs backend tests and frontend lint/build.
- Terraform files provide a local Docker provider demonstration; no AWS resources are used.

## Important
Use only logs you are authorized to process. Scrub credentials, tokens, personal data and internal hostnames before uploading or sending evidence to Gemini.
